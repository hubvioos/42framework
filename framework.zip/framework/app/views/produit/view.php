Produit/View
<?php echo $text; ?>