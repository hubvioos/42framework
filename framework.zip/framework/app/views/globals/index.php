Home
<?php echo $text; ?>
<br />
<br />
<?php
echo $this->loadFragment('pseudo', $this->vars);
?>