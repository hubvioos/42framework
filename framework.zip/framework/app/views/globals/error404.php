<?php
echo $t1;
print_r($request);
echo $t2;
?>
Erreur<br />