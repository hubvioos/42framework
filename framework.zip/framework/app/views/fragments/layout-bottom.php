<div id="footer">
			<p>Copyright 42medias.com - 2010 / Version de développement</p>	
		</div>
	</div>
</body>
</html>